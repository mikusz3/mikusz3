---
title: "My First Blog Post"
date: 2025-07-26
draft: false
---

This is the content of my first blog post in English.
